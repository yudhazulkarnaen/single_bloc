part of 'favorite_bloc.dart';

@immutable
abstract class FavoriteEvent {}

class InitialEvent extends FavoriteEvent {
  InitialEvent();
}

class FavoriteGetNext extends FavoriteEvent {
  FavoriteGetNext();
}

class FavoriteToggle extends FavoriteEvent {
  final WordPair pair;

  FavoriteToggle({
    required this.pair,
  });
}
